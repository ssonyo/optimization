import numpy as np
from config.settings import SimConfig
from core.product import Product
from core.demand_model import DemandModel
from core.base_env import InventoryEnv
from policies.fixed_policy import FixedPolicy
from policies.dynamic_policy import DynamicPolicy
from utils.stats_collector import StatsCollector
from visualization.plotter import (
    plot_simulation_results, 
    plot_learning_curve, 
    plot_sensitivity_heatmap,
    plot_inventory_aging
)

def run_single_episode(config, policy_type):
    """
    S_{t+1} = S^M(S_t, x_t, W_{t+1}) framework.
    Returns episode metrics and daily traces for visualization.
    """
    product = Product(config)
    dm = DemandModel(config)
    env = InventoryEnv(config, product, dm)
    policy = FixedPolicy(config) if policy_type == "Fixed" else DynamicPolicy(config)
    
    # Cumulative Metrics
    ep_reward, ep_waste, ep_sales = 0, 0, 0
    
    # Time-series Traces (T-axis)
    mu_trace = []
    daily_profits = []
    bin_history = [] 

    for t in range(config.T):
        # 0. State Observation
        bin_history.append(product.inventory_bins.copy())

        # 1. Action Decision (x_t)
        order_qty, prices = policy.get_action(product) 
        
        # 2. Transition (W_{t+1}, S_{t+1})
        result = env.step(order_qty, prices, policy_type=policy_type)
        
        # 3. Reward & Metrics Update
        ep_reward += result['reward']
        ep_waste += result['waste']
        ep_sales += result['demand']
        
        # 4. Record Daily Profit (Always append to ensure length = T)
        daily_profits.append(result['reward'])
        
        # 5. Belief Update (B_t) & Alpha Trace
        if policy_type == "Dynamic":
            policy.update_belief(result['demand'], prices, product)
            # Record current mu_alpha even if it didn't change today
            mu_trace.append(policy.mu_alpha)
        else:
            # For Fixed policy, trace is just the base price effect (not used for learning curve but for length match if needed)
            mu_trace.append(0.0) 
            
    return ep_reward, ep_waste, ep_sales, mu_trace, bin_history, daily_profits

def main():
    config = SimConfig()
    collector = StatsCollector()
    
    # Storage for T-axis learning/profit curves
    dynamic_mu_histories = []
    dynamic_daily_profits = []
    
    last_fixed_bins = None
    last_dynamic_bins = None

    print(f"--- Simulation Start: N={config.N}, T={config.T} ---")

    for i in range(config.N):
        # --- [1] Fixed Policy Execution ---
        r_f, w_f, s_f, _, bin_f, _ = run_single_episode(config, "Fixed")
        collector.add_episode_result("Fixed", r_f, w_f, s_f)
        
        # --- [2] Dynamic Policy Execution ---
        r_d, w_d, s_d, mu_t, bin_d, d_p = run_single_episode(config, "Dynamic")
        collector.add_episode_result("Dynamic", r_d, w_d, s_d)
        
        # Collect Dynamic-specific traces for learning curves
        dynamic_mu_histories.append(mu_t)
        dynamic_daily_profits.append(d_p)

        # Progress Monitor
        if (i + 1) % 100 == 0:
            print(f"Episode {i+1}/{config.N} completed...")

        # Keep the final episode for dashboarding
        if i == config.N - 1:
            last_fixed_bins = bin_f
            last_dynamic_bins = bin_d

    # --- Visualization 1: Reward/Waste Distributions ---
    if config.SHOW_DISTRIBUTION:
        plot_simulation_results(collector)
        
    # --- Visualization 2: Learning Curve (X-axis = T) ---
    if config.SHOW_LEARNING_CURVE:
        # Convert lists to NumPy arrays for vectorized averaging in plotter
        mu_arr = np.array(dynamic_mu_histories)
        profit_arr = np.array(dynamic_daily_profits)
        
        print(f"Plotting Learning Curve (Data shape: {mu_arr.shape})")
        plot_learning_curve(mu_arr, config.ALPHA_TRUE, profit_arr)

    # --- Visualization 3: Inventory Aging Dashboards ---
    if last_fixed_bins and last_dynamic_bins:
        plot_inventory_aging(last_fixed_bins, title="Inventory Aging: Fixed Policy")
        plot_inventory_aging(last_dynamic_bins, title="Inventory Aging: Dynamic Policy")

    # --- Visualization 4: Sensitivity Heatmap ---
    if config.SHOW_SENSITIVITY:
        run_sensitivity_analysis(config)

def run_sensitivity_analysis(config):
    print("\n--- Running Sensitivity Analysis Heatmap ---")
    heatmap_matrix = []
    for L in config.SENSITIVITY_LIFES:
        row = []
        for a in config.SENSITIVITY_ALPHAS:
            temp_config = SimConfig()
            temp_config.SHELF_LIFE = L
            temp_config.ALPHA_TRUE = a
            # Average over 30 episodes for stability
            avg_p = np.mean([run_single_episode(temp_config, "Dynamic")[0] for _ in range(30)])
            row.append(avg_p)
        heatmap_matrix.append(row)
    plot_sensitivity_heatmap(heatmap_matrix, config.SENSITIVITY_ALPHAS, config.SENSITIVITY_LIFES)

if __name__ == "__main__":
    main()