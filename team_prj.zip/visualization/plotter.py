import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd

def plot_simulation_results(stats):
    """
    StatsCollector로부터 받은 데이터를 바탕으로 성과를 비교합니다.
    1. 정책별 누적 수익 분포 (Profit Distribution)
    2. 정책별 폐기율 비교 (Waste Rate Comparison)
    """
    fixed_rewards = [d['reward'] for d in stats.results['Fixed']]
    dynamic_rewards = [d['reward'] for d in stats.results['Dynamic']]
    
    fixed_waste = [d['waste_rate'] for d in stats.results['Fixed']]
    dynamic_waste = [d['waste_rate'] for d in stats.results['Dynamic']]

    fig, axes = plt.subplots(1, 2, figsize=(15, 6))

    # [그래프 1] 수익 분포 (Histogram & KDE)
    sns.histplot(fixed_rewards, color="skyblue", label="Fixed (LIFO)", kde=True, ax=axes[0])
    sns.histplot(dynamic_rewards, color="orange", label="Dynamic (FIFO)", kde=True, ax=axes[0])
    axes[0].set_title("Cumulative Profit Distribution")
    axes[0].set_xlabel("Total Profit")
    axes[0].legend()

    # [그래프 2] 폐기율 비교 (Boxplot)
    sns.boxplot(data=[fixed_waste, dynamic_waste], palette=["skyblue", "orange"], ax=axes[1])
    axes[1].set_xticklabels(["Fixed (LIFO)", "Dynamic (FIFO)"])
    axes[1].set_title("Waste Rate Comparison")
    axes[1].set_ylabel("Waste Rate (%)")

    plt.tight_layout()
    plt.savefig("simulation_result.png")
    print("\n[The result plot is saved as 'simulation_result.png'")
    plt.show()


def plot_learning_curve(mu_history, true_alpha, daily_profit_history):
    """
    X축을 T(Days)로 통일하여 '지능의 성장'과 '수익의 증가'를 같은 시간선상에서 비교
    """
    # mu_history: (N, T) matrix
    # daily_profit_history: (N, T) matrix
    
    T = len(mu_history[0])  # 300일
    days = np.arange(T)
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))

    # --- 왼쪽: Alpha 수렴 ---
    avg_mu = np.mean(mu_history, axis=0)
    std_mu = np.std(mu_history, axis=0)

    ax1.plot(days, avg_mu, label="Estimated Alpha ($\mu_\\alpha$)", color='blue', lw=2)
    ax1.fill_between(days, avg_mu - std_mu, avg_mu + std_mu, color='blue', alpha=0.2)
    ax1.axhline(y=true_alpha, color='red', linestyle='--', label=f"True Alpha ({true_alpha})")
    ax1.set_title(f"1. Alpha Convergence (Over {T} Days)", fontsize=12)
    ax1.set_xlabel("Day (t)")
    ax1.set_ylabel("Elasticity ($\\alpha$)")
    ax1.set_xlim(0, T) # X축을 정확히 T까지 고정
    ax1.legend()
    ax1.grid(True, alpha=0.3)

    # --- 오른쪽: 일일 이익 추이 (성과) ---
    avg_profit = np.mean(daily_profit_history, axis=0)
    std_profit = np.std(daily_profit_history, axis=0)

    ax2.plot(days, avg_profit, label="Avg Daily Profit", color='green', lw=2)
    ax2.fill_between(days, avg_profit - std_profit, avg_profit + std_profit, color='green', alpha=0.1)
    
    # 이익 최적화 지점(Sweet Spot)을 보여주는 추세선
    z = np.polyfit(days, avg_profit, 3) 
    p = np.poly1d(z)
    ax2.plot(days, p(days), "darkgreen", linestyle="--", label="Profit Trend")

    ax2.set_title(f"2. Daily Profit Evolution (Over {T} Days)", fontsize=12)
    ax2.set_xlabel("Day (t)")
    ax2.set_ylabel("Daily Profit ($)")
    ax2.set_xlim(0, T) # X축을 정확히 T까지 고정
    ax2.legend()
    ax2.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.show()


def plot_sensitivity_heatmap(data_matrix, alpha_range, shelf_life_range):
    """③ 감도 분석 Heatmap: 특정 환경에서의 수익성 확인"""
    plt.figure(figsize=(10, 8))
    
    df = pd.DataFrame(data_matrix, index=shelf_life_range, columns=alpha_range)
    sns.heatmap(df, annot=True, fmt=".1f", cmap="YlGnBu")
    
    plt.title("Sensitivity Analysis: Total Profit by Alpha & Shelf Life")
    plt.xlabel("Price Elasticity ($\\alpha$)")
    plt.ylabel("Shelf Life ($L$)")
    plt.show()


def plot_inventory_aging(bin_history, title="Inventory Composition by Remaining Shelf Life"):
    """
    시간에 따른 재고의 구성(남은 유통기한별)을 시각화합니다.
    bin_history: (T, L) 형태의 리스트 또는 배열
    """
    history = np.array(bin_history)
    T, L = history.shape
    days = np.arange(T)
    
    plt.figure(figsize=(12, 6))
    # 남은 유통기한이 짧은 순서(0일 남음, 1일 남음...)대로 쌓습니다.
    labels = [f"{i+1} Day(s) Left" for i in range(L)]
    
    plt.stackplot(days, history.T, labels=labels, alpha=0.8, edgecolors='white')
    
    plt.title(title, fontsize=14)
    plt.xlabel("Time Step (Day)", fontsize=12)
    plt.ylabel("Inventory Quantity", fontsize=12)
    plt.legend(loc='upper right')
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    plt.tight_layout()
    plt.show()


def plot_inventory_flow(history):
    """단일 에피소드 동안의 재고 흐름을 시각화 (선택 사항)"""
    plt.figure(figsize=(10, 5))
    plt.plot(history['inventory'], label='Inventory Level', color='green')
    plt.plot(history['demand'], label='Actual Demand', color='red', linestyle='--')
    plt.title("Inventory & Demand Flow (Single Episode)")
    plt.legend()
    plt.show()

