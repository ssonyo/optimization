import numpy as np

def update_normal_posterior(mu_0, sigma_0, observed_demand, expected_demand, sigma_D, avg_price, base_price):
    delta_p = avg_price - base_price
    if abs(delta_p) < 1e-4:
        return mu_0, sigma_0

    safe_obs = np.clip(observed_demand, 1e-10, None)
    safe_exp = np.clip(expected_demand, 1e-10, None)

    log_obs = np.log(safe_obs)
    log_exp = np.log(safe_exp)
    innovation = log_obs - log_exp
    
    H = -delta_p
    prior_var = sigma_0**2
    
    observation_var = np.clip((sigma_D / safe_exp)**2, 1e-6, 1e6)
    
    # 칼만 이득 계산
    innovation_covariance = (H**2 * prior_var) + observation_var + 1e-9
    kalman_gain = (prior_var * H) / innovation_covariance
    
    mu_1 = mu_0 + kalman_gain * innovation
    posterior_var = (1 - kalman_gain * H) * prior_var
    sigma_1 = np.sqrt(max(1e-10, posterior_var))

    #clipping to avoid numerical issues
    if np.isnan(mu_1) or np.isinf(mu_1):
        return mu_0, sigma_0
    
    mu_1 = np.clip(mu_1, 0.01, 5.0)
    sigma_1 = np.clip(sigma_1, 0.001, 1.0)

    return mu_1, sigma_1