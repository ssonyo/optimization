import numpy as np
from scipy.stats import norm
from .base_policy import BasePolicy
from core.demand_model import DemandModel
from utils.bayesian import update_normal_posterior

class DynamicPolicy(BasePolicy):
    def __init__(self, config):
        super().__init__(config)
        self.mu_alpha = config.MU_ALPHA_0
        self.sigma_alpha = config.SIGMA_ALPHA_0

    def get_action(self, product_state):
        # Thompson Sampling: 내 믿음에서 가상의 알파(가설) 추출
        hat_alpha = norm.rvs(self.mu_alpha, self.sigma_alpha)
        hat_alpha = max(0.01, hat_alpha) 

        # 1. 가격 결정 (내 가설 hat_alpha 기반)
        prices = self._determine_prices(hat_alpha)
        
        # 2. 내 가설 하에서의 기대 수요 계산
        expected_d = DemandModel.calculate_expected_demand(product_state, prices, hat_alpha, self.config)
        
        # 3. 주문량 결정
        sigma_t = np.sqrt(product_state.sigma_demand_sq)
        target_inv = expected_d + (self.config.THETA_SAFETY * sigma_t)
        order_qty = max(0, target_inv - np.sum(product_state.inventory_bins))
        
        return int(order_qty), prices

    def update_belief(self, observed_demand, prices, product_state, method='standard'):
        # 1. 공통 정보 계산
        total_inv = np.sum(product_state.inventory_bins)
        if total_inv <= 0: return
        
        weights = product_state.inventory_bins / total_inv
        avg_price = np.sum(prices * weights)
        sigma_D = np.sqrt(product_state.sigma_demand_sq)

        if method == 'standard':
            # version1: 전체 기대 수요와 실제 관측치 비교
            expected_d = DemandModel.calculate_expected_demand(product_state, prices, self.mu_alpha, self.config)
        
        elif method == 'freshness_adjusted':
            # version2: 신선도 보정 방식
            # 1. 가격 효과를 제외한 '신선도에 의한 베이스라인'만 먼저 계산 (alpha=0 가정)
            baseline_d = DemandModel.calculate_expected_demand(product_state, prices, 0.0, self.config)
            
            # 2. 이 베이스라인을 기준으로 '순수하게 가격 때문에 변했어야 할 양'만 기대 수요로 설정
            # 이렇게 하면 Innovation 계산 시 신선도 노이즈가 제거된 '순수 가격 오차'만 추출됩니다.
            expected_d = baseline_d * np.exp(-self.mu_alpha * (avg_price - self.config.BASE_PRICE))

        self.mu_alpha, self.sigma_alpha = update_normal_posterior(
            mu_0 = self.mu_alpha,
            sigma_0 = self.sigma_alpha,
            observed_demand = observed_demand,
            expected_demand = expected_d,
            sigma_D = sigma_D,
            avg_price = avg_price,
            base_price = self.config.BASE_PRICE
        )

    def _determine_prices(self, current_alpha):
        prices = np.zeros(self.config.SHELF_LIFE)
        discount_factor = 0.1 / (current_alpha + 0.5)
        min_price = self.config.BASE_COST * 1.05

        for m_idx in range(self.config.SHELF_LIFE):
            m = m_idx + 1
            discount = (self.config.SHELF_LIFE - m) * discount_factor
            prices[m_idx] = max(min_price, self.config.BASE_PRICE * (1 - discount))
        return prices