import numpy as np
from .base_policy import BasePolicy

class FixedPolicy(BasePolicy):
    def __init__(self, config):
        super().__init__(config)

    def get_action(self, product):
        # 1. state variables 
        f_t = product.f_forecast
        sigma_t = np.sqrt(product.sigma_demand_sq)
        total_inventory = np.sum(product.inventory_bins)

        # set order quantity
        target_inventory = f_t + self.config.THETA_SAFETY * sigma_t
        order_qty = max(0, target_inventory - total_inventory)
        
        # 3. set fixed prices
        prices = np.full(self.config.SHELF_LIFE, self.config.BASE_PRICE)
        
        return int(order_qty), prices