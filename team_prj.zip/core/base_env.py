import numpy as np

class InventoryEnv:
    def __init__(self, config, product, demand_model):
        self.config = config
        self.p = product
        self.dm = demand_model

    def step(self, order_qty, prices, policy_type):
        """
        상태 전이 함수 S_{t+1} = S^M(S_t, x_t, W_{t+1}) 구현
        """
        # --- [0. 현재 상태 관측] ---
        f_old = self.p.f_forecast
        sigma_d_sq_old = self.p.sigma_demand_sq
        sigma_f_sq_old = self.p.sigma_f_sq

        # --- [1. 물리적 재고 전이 (Aging & Disposal)] ---
        # m=1인 칸은 폐기 처리 (Disposal)
        waste_qty = self.p.inventory_bins[0]
        
        # 유통기한 한 칸씩 이동 (Aging)
        temp_bins = np.zeros(self.config.SHELF_LIFE)
        temp_bins[:-1] = self.p.inventory_bins[1:]
        
        # 신규 주문 입고 (수식 1.8: R_t + x_t 부분)
        temp_bins[-1] = order_qty 

        # --- [2. 외생 정보 실현 (Exogenous Information W_{t+1})] ---
        # 수식 1.9: 실제 수요 D_hat 발생
        actual_demand = self.dm.get_actual_demand(self.p, prices, self.config.ALPHA_TRUE)

        # --- [3. 판매 처리 및 수익 계산 (Consumption)] ---
        remaining_demand = actual_demand
        revenue = 0
        
        # 정책에 따른 판매 순서 결정 (Fixed: 신선한 것부터 LIFO / Dynamic: 오래된 것부터 FIFO)
        indices = range(self.config.SHELF_LIFE - 1, -1, -1) if policy_type == "Fixed" else range(self.config.SHELF_LIFE)
        
        for i in indices:
            if remaining_demand <= 0: break
            sell_qty = min(temp_bins[i], remaining_demand)
            temp_bins[i] -= sell_qty
            remaining_demand -= sell_qty
            revenue += sell_qty * prices[i]

        # --- [4. 정보 전이 및 적응형 업데이트 (Adaptive Estimation)] ---
        eps_f = np.random.normal(0, 1.0) # 예측 노이즈
        f_new = f_old + eps_f
        
        alpha = self.config.SMOOTHING_FACTOR
        new_sigma_d_sq = (1 - alpha) * sigma_d_sq_old + alpha * (f_old - actual_demand)**2
        new_sigma_f_sq = (1 - alpha) * sigma_f_sq_old + alpha * (f_old - f_new)**2

        # --- [5. 보상 C_t 계산] ---
        order_cost = order_qty * self.p.config.BASE_COST
        holding_cost = np.sum(temp_bins) * self.config.HOLDING_COST
        waste_penalty = waste_qty * (self.p.config.BASE_COST * self.config.WASTE_COST_FACTOR)
        
        reward = revenue - order_cost - holding_cost - waste_penalty

        # --- [6. 상태 업데이트 및 디버깅] ---
        if getattr(self.config, 'DEBUG_MODE', False): 
            print(f"\n[DEBUG - {policy_type}]")
            print(f"  - Forecast f: {f_old:.1f} -> {f_new:.1f}")
            print(f"  - Sigma_D^2: {new_sigma_d_sq:.1f}")
            print(f"  - Order/Demand: {order_qty}/{actual_demand:.1f}")
            print(f"  - Profit: {reward:.2f} (Waste: {waste_qty})")

        # 제품 상태 갱신 (S_{t+1})
        self.p.inventory_bins = temp_bins
        self.p.f_forecast = f_new
        self.p.sigma_demand_sq = new_sigma_d_sq
        self.p.sigma_f_sq = new_sigma_f_sq
        
        return {
            "reward": reward,
            "waste": waste_qty,
            "demand": actual_demand,
            "inventory": np.sum(temp_bins),
            "forecast": f_new,
            "sigma_d_sq": new_sigma_d_sq
        }