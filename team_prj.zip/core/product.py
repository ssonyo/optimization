# team_prj/core/product.py
import numpy as np

class Product:
    def __init__(self, config):
        self.config = config
        self.shelf_life = config.SHELF_LIFE
        self.base_price = config.BASE_PRICE
        self.cost = config.BASE_COST
        self.reset()

    def reset(self):
        """initialize product state variables on the new episode"""
        # 1. inventory
        #self.inventory_bins = np.zeros(self.shelf_life)
        self.inventory_bins = np.array([40.0, 30.0, 0.0]) # [1일 남음, 2일 남음, 3일 남음]
        # 2. f_t
        self.f_forecast = getattr(self.config, 'INITIAL_F_FORECAST', 40.0)
        # 3. (sigma_t^2)
        self.sigma_demand_sq = getattr(self.config, 'INITIAL_SIGMA_D_SQ', 225.0)
        # 4. (sigma_f_t^2)
        self.sigma_f_sq = getattr(self.config, 'INITIAL_SIGMA_F_SQ', 1.0)