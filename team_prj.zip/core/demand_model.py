import numpy as np

class DemandModel:
    def __init__(self, config):
        self.config = config

    @staticmethod
    def calculate_expected_demand(product, prices, alpha, config):
        """
        [Public Logic] Calculates the deterministic part of the demand.
        Used by:
          - Environment (with alpha_true) -> To get the center of the distribution
          - Policy (with mu_alpha) -> To get the agent's expectation
        """
        # 1. Freshness effect (Phi)
        total_inv = np.sum(product.inventory_bins)
        
        if total_inv > 0:
            weights = product.inventory_bins / total_inv
            # Calculate weighted average phi
            # phi = exp(-gamma * (ShelfLife - m))
            avg_phi = sum(np.exp(-config.GAMMA_FRESHNESS * (config.SHELF_LIFE - (i+1))) * weights[i] 
                          for i in range(config.SHELF_LIFE))
            
            # 2. Price effect (Psi) using the PROVIDED alpha
            # psi = exp(-alpha * (P - P_base))
            avg_price_effect = sum(np.exp(-alpha * (prices[i] - config.BASE_PRICE)) * weights[i] 
                                   for i in range(config.SHELF_LIFE))
        else:
            # If no inventory, assume maximum freshness and base price for potential demand
            avg_phi = 1.0 
            avg_price_effect = 1.0

        # 3. Deterministic Base Demand
        # D_expected = f_t * Phi * Psi
        return product.f_forecast * avg_phi * avg_price_effect

    def get_actual_demand(self, product, prices, alpha_true):
        """
        [Environment Only] Generates the actual market observation W_{t+1}.
        D_actual = D_expected(alpha_true) + epsilon
        """
        # Call the shared logic using the REAL alpha
        base_demand = self.calculate_expected_demand(product, prices, alpha_true, self.config)
        
        # Add market noise
        noise = np.random.normal(0, self.config.SIGMA_D_ACTUAL)
        actual_demand = max(0, base_demand + noise)
        
        return actual_demand